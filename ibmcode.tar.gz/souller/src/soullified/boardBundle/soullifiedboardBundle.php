<?php

namespace soullified\boardBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class soullifiedboardBundle extends Bundle
{
}
