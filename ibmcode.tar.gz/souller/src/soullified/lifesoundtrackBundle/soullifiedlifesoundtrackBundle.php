<?php

namespace soullified\lifesoundtrackBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class soullifiedlifesoundtrackBundle extends Bundle
{
}
