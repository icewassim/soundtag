<?php

namespace soullified\profilBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class soullifiedprofilBundle extends Bundle
{
}
